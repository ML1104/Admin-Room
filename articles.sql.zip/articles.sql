-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 26, 2018 at 03:48 PM
-- Server version: 5.7.19
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `articles`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(225) NOT NULL,
  `category` varchar(45) NOT NULL,
  `author` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `category`, `author`) VALUES
(1, 'Whales are mammals again!!', 'Flora&Fauna', 'Nicc Cage'),
(2, 'Is it possible to cry in space?', 'Science', 'Mr. Green'),
(3, 'Speedy race car crashes into man\'s face', 'Sports', 'Jetbull'),
(4, 'Secret behind ostriches sticking their heads into things', 'Flora&Fauna', 'Fruity Casa'),
(5, 'Can you survive 2000 volts of electric shock?', 'Science', 'Betway'),
(6, 'Are frogs smarter than they seem to be?', 'Flora&Fauna', 'Vera John'),
(7, 'Gain 50 pounds with this revolutionizing diet!', 'Lifestyle', 'Casumo'),
(8, 'How to revive dead memes', 'Lifestyle', 'TheLegend27'),
(9, 'Who really the bear\'s spaget?', 'Lifestyle', 'Masha'),
(10, 'How to create Admin room in a short time?', 'Myth', 'Wild Tornado');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
